﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ELibraryMgmtSys
{
    /// <summary>
    /// Interaction logic for Administrator.xaml
    /// </summary>
    public partial class Administrator : Window
    {
        public Administrator()
        {
            InitializeComponent();
        }

        private void BtnSubmit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {
            txtID.Text = String.Empty;
            txtDname.Text = String.Empty;
            txtPath.Text = String.Empty;
            txtDecription.Text = String.Empty;
            txtDTypeID.Text = String.Empty;
            txtDID.Text = String.Empty;
            txtTitle.Text = String.Empty;
            txtAuthor.Text = String.Empty;
            txtDate.Text = String.Empty;
            txtPrice.Text = String.Empty;
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            documentDetails.Visibility = Visibility.Hidden;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            documentDetails.Visibility = Visibility.Hidden;
            viewDocuments.Visibility = Visibility.Hidden;
            viewPerson.Visibility = Visibility.Hidden;
            searchPersonal.Visibility = Visibility.Hidden;
            userDetails.Visibility = Visibility.Hidden;
        }

        private void btnAddDocument_Click(object sender, RoutedEventArgs e)
        {
            viewDocuments.Visibility = Visibility.Hidden;
            documentDetails.Visibility = Visibility.Visible;
            viewPerson.Visibility = Visibility.Hidden;
            searchPersonal.Visibility = Visibility.Hidden;
            userDetails.Visibility = Visibility.Hidden;
        }

        private void btnViewPerson_Click(object sender, RoutedEventArgs e)
        {
            documentDetails.Visibility = Visibility.Hidden;
            viewDocuments.Visibility = Visibility.Hidden;
            viewPerson.Visibility = Visibility.Visible;
            searchPersonal.Visibility = Visibility.Hidden;
            userDetails.Visibility = Visibility.Hidden;
        }

        private void btnViewDocument_Click(object sender, RoutedEventArgs e)
        {
            documentDetails.Visibility = Visibility.Hidden;
            viewDocuments.Visibility = Visibility.Visible;
            viewPerson.Visibility = Visibility.Hidden;
            searchPersonal.Visibility = Visibility.Hidden;
            userDetails.Visibility = Visibility.Hidden;

        }

        private void btnSearchPerson_Click(object sender, RoutedEventArgs e)
        {
            documentDetails.Visibility = Visibility.Hidden;
            viewDocuments.Visibility = Visibility.Hidden;
            viewPerson.Visibility = Visibility.Hidden;
            searchPersonal.Visibility = Visibility.Visible;
            userDetails.Visibility = Visibility.Hidden;

        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            documentDetails.Visibility = Visibility.Hidden;
            viewDocuments.Visibility = Visibility.Hidden;
            viewPerson.Visibility = Visibility.Hidden;
            searchPersonal.Visibility = Visibility.Hidden;
            userDetails.Visibility = Visibility.Visible;
        }

        private void BtnCancel1_Click(object sender, RoutedEventArgs e)
        {
            searchPersonal.Visibility = Visibility.Hidden;
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnCancel2_Click(object sender, RoutedEventArgs e)
        {
            userDetails.Visibility = Visibility.Hidden;
            searchPersonal.Visibility = Visibility.Visible;
        }

        private void BtnSearch1_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnCancel3_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnSearch2_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnCancel4_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnUpdate_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void BtnDelete_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void BtnCancel5_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnUpdate1_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnDelete1_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
