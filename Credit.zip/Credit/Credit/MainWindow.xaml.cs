﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Credit
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private CardBrand selectedCard;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void ProcessOrder_Click(object sender, RoutedEventArgs e)
        {
            String creditCardNumber = ccNumber.Text;

            //string cardNum = txtCreditCardNo.Text;
            int dateMonth = Convert.ToInt32(expDatemonth.Text);
            int dateYear = Convert.ToInt32(expDateyear.Text);
            string cvvNum = ccvNumber.Text;

            string currentDate = DateTime.Now.ToString();
            DateTime datevalue = (Convert.ToDateTime(currentDate.ToString()));

            int day = Convert.ToInt32(datevalue.Day.ToString());
            int month = Convert.ToInt32(datevalue.Month.ToString());
            int year = Convert.ToInt32(datevalue.Year.ToString());

            string monthCompare = DateTime.Now.Month.ToString();
            string yearCompare = DateTime.Now.Year.ToString();

            if (dateMonth >= month && dateYear >= year && cvvNum.Length == 3)
            {
                MessageBox.Show("Sucsessful");                
            }
            else
            {
                MessageBox.Show("incorrect date or cvv. ");
                
            }




            if (selectedCard == CardBrand.NotSelected)
            {
                MessageBox.Show("Please select a credit card type", "",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            //if (nameOnCard.Text == null)
            //{
            //    MessageBox.Show("Please Enter Card Name", "",
            //        MessageBoxButton.OK, MessageBoxImage.Error);
            //}

            //if(ccNumber.Text==null)
            //{
            //    MessageBox.Show("Please Enter Card Number ", "",
            //        MessageBoxButton.OK, MessageBoxImage.Error);
            //}

            else
            {
                if (CreditCardValidator.Validate(selectedCard, creditCardNumber))
                {
                    ProcessResults.Content = "Validated";
                }
                else
                {
                    ProcessResults.Content = "Validation could not be processed..";
                }
            }
        }

       

        private void OnCardSelected(object sender, RoutedEventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            string rbName = rb.Name;
            switch (rbName)
            {
                case "Visa":
                    selectedCard = CardBrand.Visa;
                    break;
                case "MasterCard":
                    selectedCard = CardBrand.MasterCard;
                    break;
                case "rupay":
                    selectedCard = CardBrand.Rupay;
                    break;
                default:
                    selectedCard = CardBrand.Rupay;
                    break;
            }
            Console.ReadLine();
        }
    }
}
