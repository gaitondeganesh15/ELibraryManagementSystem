﻿SELECT * FROM ElibMgmtSys.Document_Type_details
SELECT * FROM ElibMgmtSys.Disciplines
EXEC SP_HELP [ElibMgmtSys.Disciplines]