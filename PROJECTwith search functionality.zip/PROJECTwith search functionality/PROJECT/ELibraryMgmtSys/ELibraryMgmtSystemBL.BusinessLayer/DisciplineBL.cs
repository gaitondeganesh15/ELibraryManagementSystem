﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ELibraryMgmtSystemException.Exception1;
using System.IO;

namespace ELibraryMgmtSystemBL.BusinessLayer
{
   public class DisciplineBL
    {
        Training_24Oct18_PuneEntities objDisciplineDbContext = null;

        private List<string> fileNames = new List<string>();
        //int index = 0;
         public DisciplineBL()
        {
            objDisciplineDbContext = new Training_24Oct18_PuneEntities();
        }

        //
        public IEnumerable<Discipline> DisplayDiscipline()
        {
            IQueryable<Discipline> disciList;
            try
            {
                disciList = from objDisci in objDisciplineDbContext.Disciplines
                            select objDisci;
            }
            catch(ELibraryMgmtSysException ex)
            {
                throw ex;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return disciList;
        }

        //retrieve by id
        public int getDisciId(string disciname)
        {
            Discipline objdisci;
            List<Discipline> disciList = objDisciplineDbContext.Disciplines.ToList();
            try
            {
                objdisci = disciList.SingleOrDefault(disc => disc.Discipline_Name == disciname);
            }
            catch (ELibraryMgmtSysException)
            {
                throw;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return objdisci.Discipline_ID;
        }

        //search button to retrieve pdf files
        public List<string> GetFiles(string folder)
        {           
            var result = from n in objDisciplineDbContext.Document_Details
                         select n;

            foreach (var lst in result)
            {
                if (lst.Document_Path.Contains(folder))
                {
                    //fileNames = Directory.GetFiles(folder,"*.*", SearchOption.AllDirectories).ToList();
                    string sPath = lst.Document_Path;
                    fileNames.Add(sPath);
                }
            }

            return fileNames;
        }

    }
}
