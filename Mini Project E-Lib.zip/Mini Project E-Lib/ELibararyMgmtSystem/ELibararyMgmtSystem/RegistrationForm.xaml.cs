﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Reflection;
using ELibararyMgmtSystem.BusinessLayer;

namespace ELibararyMgmtSystem
{
    /// <summary>
    /// Interaction logic for Regist.xaml
    /// </summary>
    public partial class Regist : Window
    {
        string gender;
        string userType;
        UserDetailsBL objUDBL = new UserDetailsBL();
       ELibararyMgmtSystem.BusinessLayer.User_Details objUser = new ELibararyMgmtSystem.BusinessLayer.User_Details();
        

        StringBuilder objSB = new StringBuilder();
        
        
        public Regist()
        {
            InitializeComponent();
           
        }

        public void Add()
        {
            objUser.User_ID = txtID.Text; 
            objUser.First_Name = txtFname.Text;
            objUser.Last_Name = txtLname.Text;
            objUser.Date_Of_Birth = Convert.ToDateTime(txtDob.Text);
            objUser.Address = txtAddress.Text;
            objUser.Land_Line_Number = txtLnumber.Text;
            objUser.Mobile_Number = txtMnumber.Text;
            objUser.Area_Of_Intrests = objSB.ToString(); //checkbox
            objUser.Gender = gender; //gender
            objUser.User_Type = userType; //user type
            objUser.Password = txtPassword1.Text;

            bool status = objUDBL.AddUserDetails(objUser);
           
            if (status)
            {
                MessageBox.Show("Inserted Successfully!!!");
            }

        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            Add();
            var Admin = new Admin();   //create your new form.
            Admin.Show();    //show the new form.
            this.Close();   //only if you want to close the current form.
        }

        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {
           

        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

     

        
        private void rbtMale_Click(object sender, RoutedEventArgs e)
        {
            if (rbtMale.IsEnabled)
            {
                gender = "M";
            }
        }

        private void rbtFemale_Click(object sender, RoutedEventArgs e)
        {
            if (rbtFemale.IsEnabled)
            {
                gender = "F";
            }
        }

        private void rbtSubscriber_Click(object sender, RoutedEventArgs e)
        {
            if (rbtSubscriber.IsEnabled)
            {
                userType = rbtSubscriber.Content.ToString();
            }
        }

        private void rbtNonSubscriber_Click(object sender, RoutedEventArgs e)
        {
            if (rbtNonSubscriber.IsEnabled)
            {
                userType = rbtNonSubscriber.Content.ToString();
            }
        }
        
        private void cbLifeSci_Checked(object sender, RoutedEventArgs e)
        {
            if(cbLifeSci.IsChecked.Value == true)
            {
                objSB.Append( "Life Science ");
            }
            objSB.Append(", ");

        }

        private void cbPhySciEng_Checked(object sender, RoutedEventArgs e)
        {
            if (cbPhySciEng.IsChecked.Value == true)
            {
                objSB.Append(" Physical Science & Engineering ");
            }
            objSB.Append(", ");
        }

        private void cbSocialSci_Checked(object sender, RoutedEventArgs e)
        {
            if (cbSocialSci.IsChecked.Value == true)
            {
                objSB.Append(" Social Science & Humanities ");

            }
            objSB.Append(", ");
        }

        private void cbHealth_Checked(object sender, RoutedEventArgs e)
        {
            if (cbHealth.IsChecked.Value == true)
            {
                objSB.Append("Health");
            }
        }
    }
}
