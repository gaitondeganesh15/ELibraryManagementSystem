﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Reflection;

namespace ELibararyMgmtSystem
{
    /// <summary>
    /// Interaction logic for Regist.xaml
    /// </summary>
    public partial class Regist : Window
    {
        string gender;
        string userType;

        StringBuilder objSB = new StringBuilder();
        string areaOfInterest;

        Training_24Oct18_PuneEntities dbContext = null;
        public Regist()
        {
            InitializeComponent();
            dbContext = new Training_24Oct18_PuneEntities();
        }

      

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            var Admin = new Admin();   //create your new form.
            Admin.Show();    //show the new form.
            this.Close();   //only if you want to close the current form.

            User_Details objUser = new User_Details();
            objUser.User_ID = txtID.Text;
            objUser.First_Name = txtFname.Text;
            objUser.Last_Name = txtLname.Text;
            objUser.Date_Of_Birth = Convert.ToDateTime(txtDob.Text);
            objUser.Address = txtAddress.Text;
            objUser.Land_Line_Number = txtLnumber.Text;
            objUser.Mobile_Number = txtMnumber.Text;
            objUser.Area_Of_Intrests = objSB.ToString(); // checkbox
            objUser.Gender = gender; //gender
            objUser.User_Type = userType; //user type
            objUser.Password = txtPassword1.Text;
            


            //Product prod = new Product();
            //prod.ProductName = cmbProdName.Text;
            //    prod.ExpDate = Convert.ToDateTime(datepickerexp.Text);
            //    prod.Price = Convert.ToDecimal(cmbPrice.Text);
            //    dbContext.Products.Add(prod);
            //    dbContext.SaveChanges();
            //    MessageBox.Show("Inserted");
            //    PopulateUI();
        }

        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {
            txtAddress.Text = String.Empty;
            txtDob.Text = String.Empty;
            txtFname.Text = String.Empty;
            txtID.Text = String.Empty;
            txtLname.Text = String.Empty;
            txtLnumber.Text = String.Empty;
            txtMnumber.Text = String.Empty;
            txtPassword1.Text = String.Empty;
            txtPassword2.Text = String.Empty;

        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

     

        
        private void rbtMale_Click(object sender, RoutedEventArgs e)
        {
            if (rbtMale.IsEnabled)
            {
                gender = rbtMale.Content.ToString();
            }
        }

        private void rbtFemale_Click(object sender, RoutedEventArgs e)
        {
            if (rbtFemale.IsEnabled)
            {
                gender = rbtFemale.Content.ToString();
            }
        }

        private void rbtSubscriber_Click(object sender, RoutedEventArgs e)
        {
            if (rbtSubscriber.IsEnabled)
            {
                userType = rbtSubscriber.Content.ToString();
            }
        }

        private void rbtNonSubscriber_Click(object sender, RoutedEventArgs e)
        {
            if (rbtNonSubscriber.IsEnabled)
            {
                userType = rbtNonSubscriber.Content.ToString();
            }
        }

        private void rbtAdmin_Click(object sender, RoutedEventArgs e)
        {
            if (rbtAdmin.IsEnabled)
            {
                userType = rbtAdmin.Content.ToString();
            }
        }

        private void cbLifeSci_Checked(object sender, RoutedEventArgs e)
        {
            if(cbLifeSci.IsChecked.Value == true)
            {
                objSB.Append( "Life Science ");
            }
            
        }

        private void cbPhySciEng_Checked(object sender, RoutedEventArgs e)
        {
            if (cbPhySciEng.IsChecked.Value == true)
            {
                objSB.Append("Physical Science & Engineering ");
            }
        }

        private void cbSocialSci_Checked(object sender, RoutedEventArgs e)
        {
            if (cbSocialSci.IsChecked.Value == true)
            {
                objSB.Append("Social Science & Humanities ");
            }
        }

        private void cbHealth_Checked(object sender, RoutedEventArgs e)
        {
            if (cbHealth.IsChecked.Value == true)
            {
                objSB.Append("Health");
            }
        }
    }
}
