﻿

select * from ElibMgmtSys.User_Details