﻿/*********************************************************************
 * File                 : ELibMgmtSys.sql
 * Author Name          : Mini Project Group 3
 * Desc                 : Elibrary Management System DataBase Queries 
 * Version              : 1.0
 * Started On			: 15-Dec-2018
 * Last Modified Date   : 15-Dec-2018
 * Change Description   : Queries
 *********************************************************************/

--Creating Schema
create schema ElibMgmtSys

-- Creating Table User_Details
CREATE TABLE [ElibMgmtSys].[User_Details] (
[User_ID]  VARCHAR (15) PRIMARY KEY NOT NULL,
[First_Name] VARCHAR (50) NOT NULL,
[Last_Name] VARCHAR (50),
[Date_Of_Birth] DATE NOT NULL,
[Address] VARCHAR (1000) NOT NULL,
[Land_Line_Number] VARCHAR (15) ,
[Mobile_Number] VARCHAR (15) ,
[Area_Of_Intrests] VARCHAR (100) NOT NULL,
[Gender] VARCHAR (1) NOT NULL,
[User_Type] VARCHAR (30) NOT NULL,
[Date_Of_Registration] DATE NOT NULL,
[Password] VARCHAR (50) NOT NULL,
);

Select * from ElibMgmtSys.User_Details;

-- Creating Table Document_Details
CREATE TABLE [ElibMgmtSys].[Document_Details] (
[Document_ID]  INT IDENTITY (1, 1) NOT NULL,
[Document_Name] VARCHAR (20) NOT NULL,
[Document_Description] VARCHAR (200) NOT NULL,
[Document_Path] VARCHAR (50) NOT NULL,
[Document_Type_ID] INT FOREIGN KEY REFERENCES ElibMgmtSys.Document_Type_details(Document_Type_ID) NOT NULL,
[Discipline_ID] INT FOREIGN KEY REFERENCES ElibMgmtSys.Disciplines(Discipline_ID) NOT NULL ,
[Title] VARCHAR (30) NOT NULL ,
[Author] VARCHAR (50) NOT NULL,
[Upload_Date] DATE NOT NULL,
[Price] DOUBLE PRECISION NOT NULL,
PRIMARY KEY CLUSTERED ([Document_ID] ASC)
);

-- Creating Table Disciplines
CREATE TABLE [ElibMgmtSys].[Disciplines] (
[Discipline_ID] INT IDENTITY (1, 1) NOT NULL,
[Discipline_Name] VARCHAR (20) NOT NULL,
PRIMARY KEY CLUSTERED ([Discipline_ID] ASC)
);

-- Creating Table Document_Type_details
CREATE TABLE [ElibMgmtSys].[Document_Type_details] (
[Document_Type_ID] INT IDENTITY (1, 1) NOT NULL,
[Document_Type_Name] VARCHAR (50) NOT NULL,
PRIMARY KEY CLUSTERED ([Document_Type_ID] ASC)
);

--Creating Stored Procedure for Inserting Records into User_Details Table
CREATE PROCEDURE [ElibMgmtSys].Insert_UserDetails
@userId VARCHAR(15), 
@firstName VARCHAR(50),
@lastName VARCHAR(50),
@dateOfBirth DATE,
@address VARCHAR(1000),
@landlineNumber VARCHAR(15),
@mobileNumber VARCHAR(15),
@areaOfInterests VARCHAR(100),
@gender VARCHAR(1),
@userType VARCHAR(30),
@dateOfRegistration DATE,
@password VARCHAR(50)
AS
BEGIN
INSERT INTO [ElibMgmtSys].[User_Details] VALUES(@userId,@firstName,@lastName,@dateOfBirth,@address,@landlineNumber,@mobileNumber,@areaOfInterests,@gender,@userType,@dateOfRegistration,@password);
END

--Creating Stored Procedure for Inserting Records into Document_Details Table
CREATE PROCEDURE [ElibMgmtSys].Insert_DocumentDetails
@documentName VARCHAR(20),
@documentDescription VARCHAR(200),
@documentPath VARCHAR(50),
@documentTypeId INT,
@desciplineId INT,
@title VARCHAR(30),
@author VARCHAR(50),
@uploadDate DATE,
@price DOUBLE PRECISION
AS
BEGIN
INSERT INTO [ElibMgmtSys].[Document_Details] VALUES(@documentName,@documentDescription,@documentPath,@documentTypeId,@desciplineId,@title,@author,@uploadDate,@price);
END

--Creating Stored Procedure for Inserting Records into Desciplines Table
CREATE PROCEDURE [ElibMgmtSys].Insert_Desciplines
@desciplineName VARCHAR(20)
AS
BEGIN
INSERT INTO [ElibMgmtSys].[Disciplines] VALUES(@desciplineName);
END

--Creating Stored Procedure for Inserting Records into Document_Type_Details Table
CREATE PROCEDURE [ElibMgmtSys].Insert_DocumentTypeDetails
@documentTypeName VARCHAR(50)
AS
BEGIN
INSERT INTO [ElibMgmtSys].[Document_Type_details] VALUES(@documentTypeName);
END

--Creating Stored Procedure for Updating Records from User_Details Table
CREATE PROCEDURE [ElibMgmtSys].Update_UserDetails
@userId VARCHAR(15),
@firstName VARCHAR(50),
@lastName VARCHAR(50),
@address VARCHAR(1000),
@landlineNumber VARCHAR(15),
@mobileNumber VARCHAR(15),
@areaOfInterests VARCHAR(100),
@userType VARCHAR(30), --should be changed automatically
@password VARCHAR(50)
AS
BEGIN
UPDATE [ElibMgmtSys].[User_Details] 
SET
[First_Name]=@firstName,
[Last_Name]=@lastName,
[Address]=@address,
[Land_Line_Number]=@landlineNumber,
[Mobile_Number]=@mobileNumber,
[Area_Of_Intrests]=@areaOfInterests,
[User_Type]=@userType,
[Password]=@password
WHERE [User_ID]=@userId
END

--Creating Stored Procedure for Updating Records from Document_Details Table
CREATE PROCEDURE [ElibMgmtSys].Update_DocumentDetails
@documentId INT,
@documentName VARCHAR(20),
@documentDescription VARCHAR(200),
@documentPath VARCHAR(50),
@documentTypeId INT,
@desciplineId INT,
@price DOUBLE PRECISION
AS
BEGIN
UPDATE [ElibMgmtSys].[Document_Details]
SET
Document_Name=@documentName,
Document_Description=@documentDescription,
Document_Path=@documentPath,
Document_Type_ID=@documentTypeId,
Discipline_ID=@desciplineId,
Price=@price
WHERE Document_ID=@documentId
END

--Creating Stored Procedure for Updating Records from Disciplines Table
CREATE PROCEDURE [ElibMgmtSys].Update_Disciplines
@disciplineId INT,
@disciplineName VARCHAR(20)
AS
BEGIN
UPDATE [ElibMgmtSys].[Disciplines]
SET
Discipline_Name=@disciplineName
WHERE Discipline_ID=@disciplineId
END

--Creating Stored Procedure for Updating Records from Document_Type_Details Table
CREATE PROCEDURE [ElibMgmtSys].Update_Document_Type_Details
@documentTypeId INT,
@documentTypeName VARCHAR(50)
AS
BEGIN
UPDATE [ElibMgmtSys].[Document_Type_details]
SET
Document_Type_Name=@documentTypeName
WHERE Document_Type_ID=@documentTypeId
END

