﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

//Margin="left,top,right,bottom"

namespace ELibararyMgmtSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void WaterMarkTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btnLognIn_Click(object sender, RoutedEventArgs e)
        {
            var Disciplines = new Disciplines();   //create your new form.
            Disciplines.Show();    //show the new form.
            this.Close();   //only if you want to close the current form.
        }
    }
}
