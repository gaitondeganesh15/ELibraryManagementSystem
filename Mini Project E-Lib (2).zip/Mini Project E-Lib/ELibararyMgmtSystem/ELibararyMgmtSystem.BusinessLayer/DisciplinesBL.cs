﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ELibararyMgmtSystem.BusinessLayer
{
    class DisciplinesBL
    {
        Training_24Oct18_PuneEntities DisciplineDbContext = null;

        public DisciplinesBL()
        {
            DisciplineDbContext = new Training_24Oct18_PuneEntities();
        }

        public bool AddDiscipline(Discipline objDiscipline)
        {
            bool isAdd = false;
            try
            {
                DisciplineDbContext.Disciplines.Add(objDiscipline);
                isAdd = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isAdd;
        }


    }
}
