﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ELibraryMgmtSystemBL.BusinessLayer;

namespace ELibraryMgmtSys
{
    /// <summary>
    /// Interaction logic for DisciplineSearch.xaml
    /// </summary>
    public partial class DisciplineSearch : Window
    {
        DisciplineBL objDisBL = new DisciplineBL();
        Discipline objDis = new Discipline();

        DocumentTypeDetailsBL objDocTypeBL = new DocumentTypeDetailsBL();
        Document_Type_details objDocType = new Document_Type_details();



        public DisciplineSearch()
        {
            InitializeComponent();
            cmbDis.ItemsSource = objDisBL.DisplayDiscipline().ToList();
            cmbDis.DisplayMemberPath = "Discipline_Name";

            cmbType.ItemsSource = objDocTypeBL.DisplayDocTypeDetails().ToList();
            cmbType.DisplayMemberPath = "Document_Type_Name";
        }

        //search discipline 
        public void DisplayDisci()
        {
            objDis.Discipline_ID = objDisBL.getDisciId(cmbDis.SelectedItem.ToString());
          
        }

        //search document type
        public void DisplayDocType()
        {
            objDocType.Document_Type_ID = objDocTypeBL.getDocTypeId(cmbType.SelectedItem.ToString());
        }


    }
}
