﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ELibraryMgmtSystemException.Exception1;

namespace ELibraryMgmtSystemBL.BusinessLayer
{
   public class DisciplineBL
    {
        Training_24Oct18_PuneEntities objDisciplineDbContext = null;

         public DisciplineBL()
        {
            objDisciplineDbContext = new Training_24Oct18_PuneEntities();
        }

        //
        public IEnumerable<Discipline> DisplayDiscipline()
        {
            IQueryable<Discipline> disciList;
            try
            {
                disciList = from objDisci in objDisciplineDbContext.Disciplines
                            select objDisci;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return disciList;
        }

        //retrieve by id
        public int getDisciId(string disciname)
        {
            Discipline objdisci;
            List<Discipline> disciList = objDisciplineDbContext.Disciplines.ToList();
            try
            {
                objdisci = disciList.SingleOrDefault(disc => disc.Discipline_Name == disciname);
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return objdisci.Discipline_ID;
        }
 


    }
}
