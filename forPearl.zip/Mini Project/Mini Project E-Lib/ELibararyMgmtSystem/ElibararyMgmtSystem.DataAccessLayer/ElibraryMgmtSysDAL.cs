﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ElibararyMgmtSystem.DataAccessLayer
{
    public class ElibraryMgmtSysDAL
    {




        //Product prod = new Product();
        //prod.ProductName = cmbProdName.Text;
        //    prod.ExpDate = Convert.ToDateTime(datepickerexp.Text);
        //    prod.Price = Convert.ToDecimal(cmbPrice.Text);
        //    dbContext.Products.Add(prod);
        //    dbContext.SaveChanges();
        //    MessageBox.Show("Inserted");
        //    PopulateUI();
    }
}
