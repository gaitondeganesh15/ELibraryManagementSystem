﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ELibraryMgmtSystemBL.BusinessLayer
{
   public class UserDetailsBL
    {
        Training_24Oct18_PuneEntities UDdbContext = null;

        public UserDetailsBL()
        {
            UDdbContext = new Training_24Oct18_PuneEntities();
        }

        public bool AddUserDetails(User_Details objUser)
        {
            bool AddUD = false;
            try
            {
                UDdbContext.User_Details.Add(objUser);
                int i = UDdbContext.SaveChanges();
                if (i > 0)
                {
                    AddUD = true;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return AddUD;
        }

    }
}
