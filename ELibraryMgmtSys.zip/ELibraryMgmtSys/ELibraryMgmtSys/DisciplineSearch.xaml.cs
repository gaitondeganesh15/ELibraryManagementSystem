﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ELibraryMgmtSys
{
    /// <summary>
    /// Interaction logic for DisciplineSearch.xaml
    /// </summary>
    public partial class DisciplineSearch : Window
    {
        List<string> lst = null;
        public DisciplineSearch()
        {
            InitializeComponent();
            this.DataContext = new List<string> { "All Journals", "Life Science", "Physical Sciences and Engineering", "Social Sciences and Humanities", "Health" };
        }

        private void Decspline_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            update();
        }

        private void Allareas_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (allareas.SelectedValue.Equals("Agricultural and Biological Sciences") || allareas.SelectedValue.Equals("Biochemistry, Genetics and Molecular Biology") || allareas.SelectedValue.Equals("Immunology and Microbiology") || allareas.SelectedValue.Equals("Biochemistry, Genetics and Molecular Biology") || allareas.SelectedValue.Equals("Neuroscience"))
            {
                decspline.ItemsSource = new List<string> { "Life Science" };
            }
            if (allareas.SelectedValue.Equals("Chemical Engineering") || allareas.SelectedValue.Equals("Computer Science") || allareas.SelectedValue.Equals("Earth and Planetary Sciences") || allareas.SelectedValue.Equals("Engineering") || allareas.SelectedValue.Equals("Environmental Science") || allareas.SelectedValue.Equals("Materials Science") || allareas.SelectedValue.Equals("Mathematics") || allareas.SelectedValue.Equals("Physics and Astronomy"))
            {
                decspline.ItemsSource = new List<string> { "Physical Sciences and Engineering" };
            }
            if (allareas.SelectedValue.Equals("Arts and Humanities") || allareas.SelectedValue.Equals("Business, Management and Accounting") || allareas.SelectedValue.Equals("Decision Sciences") || allareas.SelectedValue.Equals("Economics, Econometrics and Finance") || allareas.SelectedValue.Equals("Psychology") || allareas.SelectedValue.Equals("Social Sciences"))
            {
                decspline.ItemsSource = new List<string> { "Social Sciences and Humanities" };
            }
            if (allareas.SelectedValue.Equals("Dentistry") || allareas.SelectedValue.Equals("Health Professions") || allareas.SelectedValue.Equals("Medical students") || allareas.SelectedValue.Equals("Medicine") || allareas.SelectedValue.Equals("Nursing") || allareas.SelectedValue.Equals("Pharma") || allareas.SelectedValue.Equals("Toxicology") || allareas.SelectedValue.Equals("Veterinary Science and Veterinary Medicine"))
            {
                decspline.ItemsSource = new List<string> { "Health" };
            }

        }

        public List<string> update()
        {
            if (decspline.SelectedIndex == 0)
            {
                lst = new List<string> { "Sub Categories" };
                allareas.ItemsSource = lst;
            }
            if (decspline.SelectedIndex == 1)
            {
                lst = new List<string> { "Sub Categories", "Agricultural and Biological Sciences", "Biochemistry, Genetics and Molecular Biology", "Environmental Science", "Immunology and Microbiology", "Neuroscience" };
                allareas.ItemsSource = lst;
            }
            if (decspline.SelectedIndex == 2)
            {
                lst = new List<string> { "Sub Categories", "Chemical Engineering", "Computer Science", "Earth and Planetary Sciences", "Engineering", "Environmental Science", "Materials Science", "Mathematics", "Physics and Astronomy" };
                allareas.ItemsSource = lst;
            }
            if (decspline.SelectedIndex == 3)
            {
                lst = new List<string> { "Sub Categories", "Arts and Humanities", "Business, Management and Accounting", "Decision Sciences", "Economics, Econometrics and Finance", "Psychology", "Social Sciences" };
                allareas.ItemsSource = lst;
            }
            if (decspline.SelectedIndex == 4)
            {
                lst = new List<string> { "Sub Categories", "Dentistry", "Health Professions", "Medical students", "Medicine", "Nursing", "Pharma", "Toxicology", "Veterinary Science and Veterinary Medicine" };
                allareas.ItemsSource = lst;
            }
            return lst;
        }
    }
}
