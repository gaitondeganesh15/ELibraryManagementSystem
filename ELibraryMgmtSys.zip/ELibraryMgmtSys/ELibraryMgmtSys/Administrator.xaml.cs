﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ELibraryMgmtSys
{
    /// <summary>
    /// Interaction logic for Administrator.xaml
    /// </summary>
    public partial class Administrator : Window
    {
        public Administrator()
        {
            InitializeComponent();
        }

        private void BtnSubmit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {
            txtID.Text = String.Empty;
            txtDname.Text = String.Empty;
            txtPath.Text = String.Empty;
            txtDecription.Text = String.Empty;
            txtDTypeID.Text = String.Empty;
            txtDID.Text = String.Empty;
            txtTitle.Text = String.Empty;
            txtAuthor.Text = String.Empty;
            txtDate.Text = String.Empty;
            txtPrice.Text = String.Empty;
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            documentDetails.Visibility = Visibility.Hidden;
            viewDocuments.Visibility = Visibility.Hidden;
            viewPerson.Visibility = Visibility.Hidden;
            searchPersonal.Visibility = Visibility.Hidden;
        }

        private void btnAddDocDetails_Click(object sender, RoutedEventArgs e)
        {
            viewDocuments.Visibility = Visibility.Hidden;
            documentDetails.Visibility = Visibility.Visible;
            viewPerson.Visibility = Visibility.Hidden;
            searchPersonal.Visibility = Visibility.Hidden;
        }

        private void btnViewPerson_Click(object sender, RoutedEventArgs e)
        {
            documentDetails.Visibility = Visibility.Hidden;
            viewDocuments.Visibility = Visibility.Hidden;
            viewPerson.Visibility = Visibility.Visible;
            searchPersonal.Visibility = Visibility.Hidden;
        }

        private void btnViewDoc_Click(object sender, RoutedEventArgs e)
        {
            documentDetails.Visibility = Visibility.Hidden;
            viewDocuments.Visibility = Visibility.Visible;
            viewPerson.Visibility = Visibility.Hidden;
            searchPersonal.Visibility = Visibility.Hidden;

        }

        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            documentDetails.Visibility = Visibility.Hidden;
            viewDocuments.Visibility = Visibility.Hidden;
            viewPerson.Visibility = Visibility.Hidden;
            searchPersonal.Visibility = Visibility.Visible;

        }
    }
}
