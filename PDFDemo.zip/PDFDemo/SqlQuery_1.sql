﻿CREATE TABLE [rudrendra].[SavePDFTable](

      [ID] [int] IDENTITY(1,1) NOT NULL,

      [PDFFile] [varbinary](max) NULL

     

)