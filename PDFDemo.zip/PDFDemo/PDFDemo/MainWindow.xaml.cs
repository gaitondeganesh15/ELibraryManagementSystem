﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web;


namespace PDFDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("CONNECTION STRING"))

            {

                cn.Open();

                FileStream fStream = File.OpenRead("C:\\Users\\rambike\\Desktop\\Demo.pdf");

                byte[] contents = new byte[fStream.Length];

                fStream.Read(contents, 0, (int)fStream.Length);

                fStream.Close();

                using (SqlCommand cmd = new SqlCommand("insert into SavePDFTable " + "(PDFFile)values(@data)", cn))

                {

                    cmd.Parameters.AddWithValue("@data", contents);

                    cmd.ExecuteNonQuery();

                    System.Web.HttpContext.Current.Response.Write("Pdf File Save in Dab");

                }

            }
        }

        private void BtnDisplay_Click(object sender, RoutedEventArgs e)
        {
            {

                string ToSaveFileTo = HttpContext.Current.Server.MapPath("~\\C:\\Users\\rambike\\Desktop\\File\\Demo.pdf");



                using (SqlConnection cn = new SqlConnection("CONNECTION STRING"))

                {

                    cn.Open();

                    using (SqlCommand cmd = new SqlCommand("select PDFFile from SavePDFTable  where ID='" + "1" + "' ", cn))

                    {

                        using (SqlDataReader dr = cmd.ExecuteReader(System.Data.CommandBehavior.Default))

                        {

                            if (dr.Read())

                            {



                                byte[] fileData = (byte[])dr.GetValue(0);

                                using (System.IO.FileStream fs = new System.IO.FileStream(ToSaveFileTo, System.IO.FileMode.Create, System.IO.FileAccess.ReadWrite))

                                {

                                    using (System.IO.BinaryWriter bw = new System.IO.BinaryWriter(fs))

                                    {

                                        bw.Write(fileData);

                                        bw.Close();

                                    }

                                }

                            }



                            dr.Close();

                            HttpContext.Current.Response.Redirect("~\\C:\\Users\\rambike\\Desktop\\File\\Demo.pdf");

                        }

                    }

                }
            }
        }
    }
}