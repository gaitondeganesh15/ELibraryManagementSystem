﻿insert into ElibMgmtSys.Disciplines values('Life Science');
insert into ElibMgmtSys.Disciplines values('Physical Sciences');
insert into ElibMgmtSys.Disciplines values('Social Sciences');
insert into ElibMgmtSys.Disciplines values('Health');
insert into ElibMgmtSys.Disciplines values('Engineering');

select * from ElibMgmtSys.Disciplines;

alter table  ElibMgmtSys.Disciplines drop constraint 

exec sp_help [ElibMgmtSys.Disciplines]
select * from ElibMgmtSys.Document_Type_details
truncate table ElibMgmtSys.Disciplines

insert into ElibMgmtSys.Document_Type_details values('Thesis');
insert into ElibMgmtSys.Document_Type_details values('Article');
insert into ElibMgmtSys.Document_Type_details values('Journal');
insert into ElibMgmtSys.Document_Type_details values('Paper');
select * from ElibMgmtSys.Document_Type_details

drop table [ElibMgmtSys].[Document_Details];

drop table [ElibMgmtSys].[Document_Type_details];
drop table [ElibMgmtSys].Disciplines;

CREATE TABLE [ElibMgmtSys].[Document_Type_details] (
[Document_Type_ID] INT IDENTITY (1, 1) NOT NULL Constraint pk_docTypeDetails PRIMARY KEY ,
[Document_Type_Name] VARCHAR (50) NOT NULL
);
SELECT * FROM [ElibMgmtSys].[Document_Type_details]
select * from [ElibMgmtSys].[Document_Details]

CREATE TABLE [ElibMgmtSys].[Document_Details] (
[Document_ID]  INT IDENTITY (1, 1) NOT NULL  Constraint pk_docId PRIMARY KEY,
[Document_Name] VARCHAR (20) NOT NULL,
[Document_Description] VARCHAR (200) NOT NULL,
[Document_Path] VARCHAR (50) NOT NULL,
[Document_Type_ID] INT Constraint fk_docType FOREIGN KEY(Document_Type_ID) REFERENCES ElibMgmtSys.Document_Type_details(Document_Type_ID) NOT NULL,
[Discipline_ID] INT Constraint fk_disId FOREIGN KEY (Discipline_ID) REFERENCES ElibMgmtSys.Disciplines(Discipline_ID) NOT NULL ,
[Title] VARCHAR (30) NOT NULL ,
[Author] VARCHAR (50) NOT NULL,
[Upload_Date] DATE NOT NULL,
[Price] DOUBLE PRECISION NOT NULL, 
);
CREATE TABLE [ElibMgmtSys].[Disciplines] (
[Discipline_ID] INT IDENTITY (1, 1) NOT NULL CONSTRAINT pk_disId PRIMARY KEY,
[Discipline_Name] VARCHAR (20) NOT NULL,
 
);