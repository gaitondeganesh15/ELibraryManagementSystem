﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ELibraryMgmtSystemBL.BusinessLayer
{
   public class StringValueDocumentPath
    {
        public StringValueDocumentPath(string s)
        {
            _value = s;
        }
        public string Value
        {
            get
            {
                return _value;
            }
            set
            {
                _value = value;
            }
        }
        string _value;

    }
}
