﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ELibraryMgmtSystemBL.BusinessLayer;
using System.IO;

namespace ELibraryMgmtSys
{
    /// <summary>
    /// Interaction logic for DisciplineSearch.xaml
    /// </summary>
    public partial class DisciplineSearch : Window
    {
        DisciplineBL objDisBL = new DisciplineBL();
        Discipline objDis = new Discipline();

        DocumentTypeDetailsBL objDocTypeBL = new DocumentTypeDetailsBL();
        Document_Type_details objDocType = new Document_Type_details();
        StringValueDocumentPath strDocument = null;
        List<string> files = new List<string>();
        //String strfiles = new String();



        public DisciplineSearch()
        {
            InitializeComponent();
            cmbDis.ItemsSource = objDisBL.DisplayDiscipline().ToList();
            cmbDis.DisplayMemberPath = "Discipline_Name";

            cmbType.ItemsSource = objDocTypeBL.DisplayDocTypeDetails().ToList();
            cmbType.DisplayMemberPath = "Document_Type_Name";
        }

        //search discipline 
        public void DisplayDisci()
        {
            objDis.Discipline_ID = objDisBL.getDisciId(cmbDis.SelectedItem.ToString());
          
        }

        //search document type
        public void DisplayDocType()
        {
            objDocType.Document_Type_ID = objDocTypeBL.getDocTypeId(cmbType.SelectedItem.ToString());
        }

        public void GetFiles()
        {
            List<StringValueDocumentPath> lsDocumetsList = new List<StringValueDocumentPath>();
            try
            {
                string folderName = txtSearch.Text;
                List<string> files = objDisBL.GetFiles(folderName);

                foreach (var item in files)
                {
                    strDocument = new StringValueDocumentPath(item);
                    lsDocumetsList.Add(strDocument);

                }
                dgFiles.ItemsSource = lsDocumetsList;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
          

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            GetFiles();           
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //dgFiles.ItemsSource = files;
            //List<string> abc = new List<string> { "ewrf", "ewrwse", "ewrf", "ewrwse", "ewrf", "ewrwse", "ewrf", "ewrwse", "ewrf", "ewrwse", "ewrf", "ewrwse" };
            //dgFiles.ItemsSource = abc;
        }
    }
}



