﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ELibraryMgmtSystemBL.BusinessLayer;

namespace ELibraryMgmtSys
{
    /// <summary>
    /// Interaction logic for Administrator.xaml
    /// </summary>
    public partial class Administrator : Window
    {
        DocumentDetailsBL objDocDetailsBL = new DocumentDetailsBL();
        Document_Details objDocutmentDetails = new Document_Details();

        public Administrator()
        {
            InitializeComponent();
        }



        public void Insert1()  //for inserting data into Document Details Page.
        {


            objDocutmentDetails.Document_ID = Convert.ToInt32(txtID.Text);
            objDocutmentDetails.Document_Name = txtDname.Text;
            objDocutmentDetails.Document_Description = txtDecription.Text;
            objDocutmentDetails.Document_Path = txtPath.Text;
            objDocutmentDetails.Document_Type_ID = Convert.ToInt32(txtDTypeID.Text);
            objDocutmentDetails.Discipline_ID = Convert.ToInt32(txtDID.Text);
            objDocutmentDetails.Title = txtTitle.Text;
            objDocutmentDetails.Author = txtAuthor.Text;
            objDocutmentDetails.Upload_Date = Convert.ToDateTime(txtDate.Text);
            objDocutmentDetails.Price = Convert.ToInt32(txtPrice.Text);


            bool status = objDocDetailsBL.AddDocumentDetails(objDocutmentDetails);
            if (status)
            {
                MessageBox.Show("Submitted Successfully!!!");
            }
        }
       

        //1st canvas 3 buttons
        private void BtnAddDocDetails_Click(object sender, RoutedEventArgs e)
        {
            viewDocumentsSearch.Visibility = Visibility.Hidden;
            addDocumentDetails.Visibility = Visibility.Visible;
            searchPersonal.Visibility = Visibility.Hidden;
            userDetails.Visibility = Visibility.Hidden;
            viewDocumentDetails.Visibility = Visibility.Hidden;
        }


        private void BtnViewDoc_Click(object sender, RoutedEventArgs e)
        {
            addDocumentDetails.Visibility = Visibility.Hidden;
            viewDocumentsSearch.Visibility = Visibility.Visible;
            searchPersonal.Visibility = Visibility.Hidden;
            userDetails.Visibility = Visibility.Hidden;
            viewDocumentDetails.Visibility = Visibility.Hidden;

        }

        private void BtnView_Click(object sender, RoutedEventArgs e)  //search user OR EDIT USER
        {
            addDocumentDetails.Visibility = Visibility.Hidden;
            viewDocumentsSearch.Visibility = Visibility.Hidden;
            searchPersonal.Visibility = Visibility.Visible;
            userDetails.Visibility = Visibility.Hidden;
            viewDocumentDetails.Visibility = Visibility.Hidden;
        }

        //document 3 buttons

        private void BtnSubmit_Click(object sender, RoutedEventArgs e)
        {
            Insert1();
        }

        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {
            txtID.Text = String.Empty;
            txtDname.Text = String.Empty;
            txtPath.Text = String.Empty;
            txtDecription.Text = String.Empty;
            txtDTypeID.Text = String.Empty;
            txtDID.Text = String.Empty;
            txtTitle.Text = String.Empty;
            txtAuthor.Text = String.Empty;
            txtDate.Text = String.Empty;
            txtPrice.Text = String.Empty;
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            addDocumentDetails.Visibility = Visibility.Hidden;
        }

        //nested search of document edit
        private void ViewDocumentsSearch_btnSearch_Click(object sender, RoutedEventArgs e)
        {
            viewDocumentsSearch.Visibility = Visibility.Hidden;
            viewDocumentDetails.Visibility = Visibility.Visible;
        }

        private void ViewDocumentsSearch_btnClose_Click(object sender, RoutedEventArgs e)
        {
            viewDocumentsSearch.Visibility = Visibility.Hidden;
        }

        //document update 3 buttons
        private void ViewDocuments_btnUpdate_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ViewDocuments_btnReset_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ViewDocuments_btnClose_Click(object sender, RoutedEventArgs e)
        {
            viewDocumentDetails.Visibility = Visibility.Hidden;
            viewDocumentsSearch.Visibility = Visibility.Visible;
        }

        //user search nested 2 buttons
        private void SearchPersonal_btnSearch_Click(object sender, RoutedEventArgs e)
        {
            searchPersonal.Visibility = Visibility.Hidden;
            userDetails.Visibility = Visibility.Visible;
        }

        private void SearchPersonal_btnClose_Click(object sender, RoutedEventArgs e)
        {
            searchPersonal.Visibility = Visibility.Hidden;
        }

        //user update 3 buttons
        private void UserDetails_btnUpdate_Click(object sender, RoutedEventArgs e)
        {

        }

        private void UserDetails_btnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void UserDetails_btnClose_Click(object sender, RoutedEventArgs e)
        {
            userDetails.Visibility = Visibility.Hidden;
            searchPersonal.Visibility = Visibility.Visible;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            addDocumentDetails.Visibility = Visibility.Hidden;
            viewDocumentsSearch.Visibility = Visibility.Hidden;
            viewDocumentDetails.Visibility = Visibility.Hidden;
            searchPersonal.Visibility = Visibility.Hidden;
            userDetails.Visibility = Visibility.Hidden;
        }
    }
}