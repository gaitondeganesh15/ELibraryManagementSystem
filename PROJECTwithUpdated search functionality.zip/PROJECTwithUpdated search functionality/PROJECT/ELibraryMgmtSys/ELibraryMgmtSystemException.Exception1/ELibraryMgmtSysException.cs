﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ELibraryMgmtSystemException.Exception1
{
    public class ELibraryMgmtSysException: ApplicationException
    {
        public ELibraryMgmtSysException() : base()
        {

        }
        public ELibraryMgmtSysException(string message) : base(message)
        {

        }
        public ELibraryMgmtSysException(string message,Exception exception) : base(message, exception)
        {

        }
    }
}
