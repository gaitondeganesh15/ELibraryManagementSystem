﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ELibraryMgmtSys
{
    /// <summary>
    /// Interaction logic for RegistrationForm.xaml
    /// </summary>
    public partial class RegistrationForm : Window
    {
        string gender;
        string userType;

        StringBuilder objSB = new StringBuilder();

        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            creditCard.Visibility = Visibility.Visible;

            //User_Details objUser = new User_Details();
            //objUser.User_ID = txtID.Text;
            //objUser.First_Name = txtFname.Text;
            //objUser.Last_Name = txtLname.Text;
            //objUser.Date_Of_Birth = Convert.ToDateTime(txtDob.Text);
            //objUser.Address = txtAddress.Text;
            //objUser.Land_Line_Number = txtLnumber.Text;
            //objUser.Mobile_Number = txtMnumber.Text;
            //objUser.Area_Of_Intrests = objSB.ToString(); // checkbox
            //objUser.Gender = gender; //gender
            //objUser.User_Type = userType; //user type
            //objUser.Password = txtPassword1.Text;
            //dbContext.User_Details.Add(objUser);
            //dbContext.SaveChanges();
            //MessageBox.Show("Inserted !");

            //var Admin = new Admin();   //create your new form.
            //Admin.Show();    //show the new form.
            //this.Close();   //only if you want to close the current form.

        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            txtAddress.Text = String.Empty;
            txtDob.Text = String.Empty;
            txtFname.Text = String.Empty;
            txtID.Text = String.Empty;
            txtLname.Text = String.Empty;
            txtLnumber.Text = String.Empty;
            txtMnumber.Text = String.Empty;
            txtPassword1.Text = String.Empty;
            txtPassword2.Text = String.Empty;

        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void rbtMale_Click(object sender, RoutedEventArgs e)
        {
            if (rbtMale.IsEnabled)
            {
                gender = "M";
            }
        }
        private void rbtFemale_Click(object sender, RoutedEventArgs e)
        {
            if (rbtFemale.IsEnabled)
            {
                gender = "F";
            }
        }
        private void rbtOther_Click(object sender, RoutedEventArgs e)
        {
            if (rbtOther.IsEnabled)
            {
                gender = "O";
            }
        }

        private void rbtSubscriber_Click(object sender, RoutedEventArgs e)
        {
            if (rbtSubscriber.IsEnabled)
            {
                userType = rbtSubscriber.Content.ToString();
            }
        }

        private void rbtNonSubscriber_Click(object sender, RoutedEventArgs e)
        {
            if (rbtNonSubscriber.IsEnabled)
            {
                userType = rbtNonSubscriber.Content.ToString();
            }
        }

        private void cbLifeSci_Checked(object sender, RoutedEventArgs e)
        {
            if (cbLifeSci.IsChecked.Value == true)
            {
                objSB.Append("Life Science ");
            }
            objSB.Append(", ");

        }

        private void cbPhySciEng_Checked(object sender, RoutedEventArgs e)
        {
            if (cbPhySciEng.IsChecked.Value == true)
            {
                objSB.Append(" Physical Science & Engineering ");
            }
            objSB.Append(", ");
        }

        private void cbSocialSci_Checked(object sender, RoutedEventArgs e)
        {
            if (cbSocialSci.IsChecked.Value == true)
            {
                objSB.Append(" Social Science & Humanities ");

            }
            objSB.Append(", ");
        }

        private void cbHealth_Checked(object sender, RoutedEventArgs e)
        {
            if (cbHealth.IsChecked.Value == true)
            {
                objSB.Append("Health");
            }
        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {
            creditCard.Visibility = Visibility.Hidden;
        }
    }
}
