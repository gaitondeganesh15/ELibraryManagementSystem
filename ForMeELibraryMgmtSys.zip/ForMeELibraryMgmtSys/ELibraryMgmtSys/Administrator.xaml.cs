﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ELibraryMgmtSys
{
    /// <summary>
    /// Interaction logic for Administrator.xaml
    /// </summary>
    public partial class Administrator : Window
    {
        public Administrator()
        {
            InitializeComponent();
        }
        
        // #######******* On Window Loaded Contols #######*******
        
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            addDocumentDetails.Visibility = Visibility.Hidden;
            viewDocumentsSearch.Visibility = Visibility.Hidden;
            viewDocumentDetails.Visibility = Visibility.Hidden;
            viewPerson.Visibility = Visibility.Hidden;
            searchPersonal.Visibility = Visibility.Hidden;
            userDetails.Visibility = Visibility.Hidden;
            viewUserDetails.Visibility = Visibility.Hidden;
        }

        // #######*******  Buttons Option Controls #######*******

        private void btnAddDocument_Click(object sender, RoutedEventArgs e)
        {
            viewDocumentsSearch.Visibility = Visibility.Hidden;
            addDocumentDetails.Visibility = Visibility.Visible;
            viewPerson.Visibility = Visibility.Hidden;
            searchPersonal.Visibility = Visibility.Hidden;
            userDetails.Visibility = Visibility.Hidden;
            viewDocumentDetails.Visibility = Visibility.Hidden;
            viewUserDetails.Visibility = Visibility.Hidden;
        }

        private void btnViewPerson_Click(object sender, RoutedEventArgs e)
        {
            addDocumentDetails.Visibility = Visibility.Hidden;
            viewDocumentsSearch.Visibility = Visibility.Hidden;
            viewPerson.Visibility = Visibility.Visible;
            searchPersonal.Visibility = Visibility.Hidden;
            userDetails.Visibility = Visibility.Hidden;
            viewDocumentDetails.Visibility = Visibility.Hidden;
            viewUserDetails.Visibility = Visibility.Hidden;
        }

        private void btnViewDocument_Click(object sender, RoutedEventArgs e)
        {
            addDocumentDetails.Visibility = Visibility.Hidden;
            viewDocumentsSearch.Visibility = Visibility.Visible;
            viewPerson.Visibility = Visibility.Hidden;
            searchPersonal.Visibility = Visibility.Hidden;
            userDetails.Visibility = Visibility.Hidden;
            viewDocumentDetails.Visibility = Visibility.Hidden;
            viewUserDetails.Visibility = Visibility.Hidden;

        }

        private void btnEditUserDetails_Click(object sender, RoutedEventArgs e)
        {
            addDocumentDetails.Visibility = Visibility.Hidden;
            viewDocumentsSearch.Visibility = Visibility.Hidden;
            viewPerson.Visibility = Visibility.Hidden;
            searchPersonal.Visibility = Visibility.Visible;
            userDetails.Visibility = Visibility.Hidden;
            viewDocumentDetails.Visibility = Visibility.Hidden;
            viewUserDetails.Visibility = Visibility.Hidden;

        }
        
        //  #######******* Add Documnet Details Controls #######*******


        private void addDocumentDetails_btnSubmit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void addDocumentDetails_btnReset_Click(object sender, RoutedEventArgs e)
        {
            txtID.Text = String.Empty;
            txtDname.Text = String.Empty;
            txtPath.Text = String.Empty;
            txtDecription.Text = String.Empty;
            txtDTypeID.Text = String.Empty;
            txtDID.Text = String.Empty;
            txtTitle.Text = String.Empty;
            txtAuthor.Text = String.Empty;
            txtDate.Text = String.Empty;
            txtPrice.Text = String.Empty;

        }

        private void addDocumentDetails_btnClose_Click(object sender, RoutedEventArgs e)
        {
            addDocumentDetails.Visibility = Visibility.Hidden;
        }

        //  #######******* View Person Controls #######*******

        private void viewPerson_btnSearch_Click(object sender, RoutedEventArgs e)
        {
            viewPerson.Visibility = Visibility.Hidden;
            viewUserDetails.Visibility = Visibility.Visible;
        }

        private void viewPerson_btnClose_Click(object sender, RoutedEventArgs e)
        {
            viewPerson.Visibility = Visibility.Hidden;
        }

            // View User Details

        private void viewUserDetails_btnClose_Click(object sender, RoutedEventArgs e)
        {
            viewUserDetails.Visibility = Visibility.Hidden;
            viewPerson.Visibility = Visibility.Visible;
        }

        // #######******* View Document Controls #######*******
        // View Document Search

        private void viewDocumentsSearch_btnSearch_Click(object sender, RoutedEventArgs e)
        {
            viewDocumentsSearch.Visibility = Visibility.Hidden;
            viewDocumentDetails.Visibility = Visibility.Visible;
        }

        private void viewDocumentsSearch_btnClose_Click(object sender, RoutedEventArgs e)
        {
            viewDocumentsSearch.Visibility = Visibility.Hidden;
        }
        
            // View Document Details

        private void viewDocuments_btnUpdate_Click(object sender, RoutedEventArgs e)
        {

        }

        private void viewDocuments_btnReset_Click(object sender, RoutedEventArgs e)
        {

        }

        private void viewDocuments_btnClose_Click(object sender, RoutedEventArgs e)
        {
            viewDocumentDetails.Visibility = Visibility.Hidden;
            viewDocumentsSearch.Visibility = Visibility.Visible;
        }

        // #######******* Edit User Details #######*******

        private void searchPersonal_btnSearch_Click(object sender, RoutedEventArgs e)
        {
            searchPersonal.Visibility = Visibility.Hidden;
            userDetails.Visibility = Visibility.Visible;
        }

        private void searchPersonal_btnClose_Click(object sender, RoutedEventArgs e)
        {
            searchPersonal.Visibility = Visibility.Hidden;
        }

            // Edit User Details

        private void userDetails_btnUpdate_Click(object sender, RoutedEventArgs e)
        {

        }

        private void userDetails_btnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void userDetails_btnClose_Click(object sender, RoutedEventArgs e)
        {
            userDetails.Visibility = Visibility.Hidden;
            searchPersonal.Visibility = Visibility.Visible;
        }

        
    }
}
